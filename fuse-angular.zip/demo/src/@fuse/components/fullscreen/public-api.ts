export * from '@fuse/components/fullscreen/fullscreen.component';
